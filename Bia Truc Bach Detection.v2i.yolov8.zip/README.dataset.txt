# Bia Truc Bach Detection > 2024-07-19 8:22am
https://universe.roboflow.com/nhandienbia/bia-truc-bach-detection

Provided by a Roboflow user
License: CC BY 4.0

